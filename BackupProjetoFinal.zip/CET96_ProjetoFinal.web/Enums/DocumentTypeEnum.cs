﻿namespace CET96_ProjetoFinal.web.Enums
{
    public enum DocumentTypeEnum
    {
        CitizenCard = 1,
        Other = 2
    }
}
